package BST_A2;

public class BST implements BST_Interface {
	public BST_Node root;
	int size;

	public BST() {
		size = 0;
		root = null;
	}

	@Override
	// used for testing, please leave as is
	public BST_Node getRoot() {
		return root;
	}

	@Override
	public boolean insert(String s) {
		// TODO Auto-generated method stub

		if (root == null) {
			root = new BST_Node(s);
			size++;
			return true;
		} else {
			root.insertNode(s, this, root);
		}
		return false;
	}

	@Override
	public boolean remove(String s) {
		// TODO Auto-generated method stub
		if (size == 0) {
			return false;
		}
		if (root.data.compareTo(s) == 0) {
			if (root.getLeft() == null &&root.getRight()== null) {
				root = null;
				size--;
				return true;
			}
			if (root.getLeft() != null && root.getRight() == null) {
				root = root.left;
				size--;
				return true;
			}
			if (root.getRight() != null && root.getLeft() == null) {
				root = root.right;
				size--;
				return true;
			}
		}
		root.removeNode(s, this, this.root);
		return false;
	}

	@Override
	public String findMin() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return null;
		}
		return root.findMin(root).getData();
	}

	@Override
	public String findMax() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return null;
		}
		return root.findMax(root).getData();
	}

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean contains(String s) {
		// TODO Auto-generated method stub
		if (root == null) {
			return false;
		} else if (root.getData().compareTo(s) == 0) {
			return true;
		} else {
			return root.containsNode(s, this, root);
		}
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int height() {
		// TODO Auto-generated method stub
		if (root == null) {
			return -1;
		}
		return root.getHeight(root);
	}

}

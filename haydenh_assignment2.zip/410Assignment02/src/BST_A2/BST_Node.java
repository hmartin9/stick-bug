package BST_A2;

public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;
	BST_Node tempNode;

	BST_Node(String data) {
		this.data = data;
	}

	// --- used for testing ----------------------------------------------
	//
	// leave these 3 methods in, as is

	public String getData() {
		return data;
	}

	public BST_Node getLeft() {
		return left;
	}

	public BST_Node getRight() {
		return right;
	}

	// --- end used for testing -------------------------------------------

	// --- fill in these methods ------------------------------------------
	//
	// at the moment, they are stubs returning false
	// or some appropriate "fake" value
	//
	// you make them work properly
	// add the meat of correct implementation logic to them

	// you MAY change the signatures if you wish...
	// make the take more or different parameters
	// have them return different types
	//
	// you may use recursive or iterative implementations

	public boolean containsNode(String s, BST tree, BST_Node node) {

		if (node.data.compareTo(s) == 0) {
			return true;
		}

		if (node.data.compareTo(s) > 0) {
			node = node.getLeft();
			if (node == null) {
				return false;
			}
			return containsNode(s, tree, node);
		} else if (node.data.compareTo(s) < 0) {
			node = node.getRight();
			if (node == null) {
				return false;
			}
			return containsNode(s, tree, node);
		}

		return false;
	}

	public boolean insertNode(String s, BST tree, BST_Node node) {

		if (node == null) {
			node = new BST_Node(s);
			if (tempNode.data.compareTo(node.data) > 0) {
				tempNode.left = node;
				tree.size++;
			} else if (tempNode.data.compareTo(node.data) < 0) {
				tempNode.right = node;
				tree.size++;
			}
			
		}

		if (node.data.compareTo(s) == 0) {
			return false;
		} else if (node.data.compareTo(s) > 0) {
			tempNode = node;
			node = node.left;
			insertNode(s, tree, node);
		} else if (node.data.compareTo(s) < 0) {
			tempNode = node;
			node = node.right;
			insertNode(s, tree, node);

		}
		return false;

	}

	public boolean removeNode(String s, BST tree, BST_Node parent) {
		
		if (!containsNode(s, tree, parent)) {
			return false;
		}else if(this.data.compareTo(s) > 0){
			return this.left.removeNode(s, tree, this);
		}else if(this.data.compareTo(s) < 0) {
			return this.right.removeNode(s, tree, this);
		}/*else if (this.data.compareTo(s) == 0) {
			tree.root = null;
			return true;
		}*/
		
		if (this.getRight() == null && this.getLeft() == null) {
			
			if (parent.data.compareTo(this.getData()) > 0) {
				parent.left = null;
				tree.size--;
			} else if (parent.data.compareTo(this.getData()) < 0) {
				parent.right = null;
				tree.size--;
			}else if (parent.data.compareTo(this.getData())==0) {
				parent.left = null;
				tree.size--;
			}
			
			return true;
		}
		
		if (this.getRight() != null && this.getLeft() == null) {
			if (parent.data.compareTo(this.getData()) > 0) {
				parent.left = this.right;
				tree.size--;
				// address for other side
			}else if(parent.data.compareTo(this.getData()) < 0) {
				parent.right = this.right;
				tree.size--;
			}
			return true;
		}
		
		if (this.getLeft() != null && this.getRight() == null) {
			if(parent.data.compareTo(this.getData()) < 0) {
				parent.right = this.left;
				tree.size--;
			}else if(parent.data.compareTo(this.getData()) > 0) {
				parent.left = this.left;
				tree.size--;
			}
		}
		
		if (this.getRight() != null && this.getLeft() != null) {
			this.data = this.left.findMax(this.left).data;
			return left.removeNode(this.left.findMax(this.left).data, tree, this);
			}
		
		return false;
	}

	public BST_Node findMin(BST_Node root) {
		BST_Node travNode = root;

		while (travNode.getLeft() != null) {
			travNode = travNode.left;
		}

		return travNode;
	}

	public BST_Node findMax(BST_Node root) {
		BST_Node travNode = root;

		while (travNode.getRight() != null) {
			travNode = travNode.right;
		}

		return travNode;
	}

	public int getHeight(BST_Node node) {
		if (node == null) {
			return -1;
		}
		return 1+Math.max(this.getHeight(node.left), this.getHeight(node.right));
	}

	// --- end fill in these methods --------------------------------------

	// --------------------------------------------------------------------
	// you may add any other methods you want to get the job done
	// --------------------------------------------------------------------

	public String toString() {
		return "Data: " + this.data + ", Left: " + ((this.left != null) ? left.data : "null") + ",Right: "
				+ ((this.right != null) ? right.data : "null");
	}
}
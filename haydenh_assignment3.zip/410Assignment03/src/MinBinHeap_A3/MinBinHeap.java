package MinBinHeap_A3;

import java.lang.*;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; // load this array
	private int size = 0;
	// private int hole = size+1;
	private static final int arraySize = 10000; // Everything in the array will initially
												// be null. This is ok! Just build out
												// from array[1]

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); // 0th will be unused for simplicity
													// of child/parent computations...
													// the book/animation page both do this.
	}

	// Please do not remove or modify this method! Used to test your entire Heap.
	@Override
	public EntryPair[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {
		int hole = size + 1;

		if (size == 0) {
			array[1] = entry;
			size++;
		} else if (size > 0) {
			array[hole] = entry;
			size++;
		}

		if (array[hole / 2].priority > array[hole].priority) {
			EntryPair tempPair;

			while (array[hole / 2].priority > array[hole].priority) {
				tempPair = array[hole / 2];
				array[hole / 2] = array[hole];
				array[hole] = tempPair;
				hole = hole / 2;
			}
		}

		// int hole = ++size;
		// for (array[1] = entry; array[hole / 2].priority < entry.priority; hole /= 2)
		// {
		// array[hole] = array[hole / 2];
		// array[hole] = entry;
		//
		// }

	}

	@Override
	public void delMin() {
		// TODO Auto-generated method stub
		EntryPair tempPair;
		int hole = 1;
		int child;

		array[hole] = array[size];
		array[size] = null;
		size--;

		if (array[hole * 2] != null && array[hole * 2 + 1] != null) {
			while (array[hole].priority > array[hole * 2].priority) {
			//		|| array[hole].priority > array[hole * 2 + 1].priority) {

				tempPair = array[hole];
				child = hole * 2;

				if (array[child + 1] != null) {
					if (array[child].priority > array[child + 1].priority)
						child++;
				}

				array[hole] = array[child];
				array[child] = tempPair;
				hole = child;

				if (hole * 2 > size ) //|| hole * 2 + 1 > size)
					break;

			}
		} else if (array[hole * 2 + 1] == null && array[hole * 2] != null) {
			while (array[hole].priority > array[hole * 2].priority) {
				tempPair = array[hole];
				child = hole * 2;

				array[hole] = array[child];
				array[child] = tempPair;
				hole = child;

				if (hole * 2 > size)
					break;
			}
		} else if (array[hole * 2] == null) {
			hole--;
		}

		// for (; hole*2 <= size; hole = child) {
		// child = hole*2;
		// if (child != size && array[child + 1].priority < array[child].priority) {
		// child++;
		// }
		// if (array[child].priority < tempPair.priority) {
		// array[hole] = array[child];
		// }else {
		// break;
		// }
		// array[hole] = tempPair;
		// }
		// tempPair = array[hole-1];
		// while (array[hole].priority > array[hole*2].priority && array[hole].priority
		// > array[hole*2+1].priority) {
		// array[hole].priority = Math.min(array[hole*2].priority,
		// array[hole*2+1].priority);

	}

	@Override
	public EntryPair getMin() {
		// TODO Auto-generated method stub
		return array[1];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {
		int child;
		int parent;
		int hole;
		EntryPair tempPair;

		int i = 1;
		for (EntryPair entry : entries) {
			array[i++] = entry;
			size++;
		}

		for (int j = size / 2; j > 0; j--) {
			hole = j;
			tempPair = array[hole];
			for (; hole * 2 <= size; hole = child) {
				child = hole * 2;
				if (child != size && array[child + 1].priority < array[child].priority) {
					child++;
				}
				if (array[child].priority < tempPair.priority) {
					array[hole] = array[child];
				} else
					break;
			}
			array[hole] = tempPair;
		}

		// if (array[parent*2] == null && array[parent*2+1] == null) {
		// parent--;
		// this.build(entries);
		// }
		//
		// if (array[parent * 2] != null && array[parent * 2 + 1] != null) {
		// child = parent * 2;
		// while (array[parent].priority > array[child].priority
		// || array[parent].priority > array[child + 1].priority) {
		//
		// if (array[child].priority > array[child + 1].priority) {
		// child--;
		// }
		//
		// tempPair = array[parent];
		// array[parent] = array[child];
		// array[child] = tempPair;
		// parent--;
		// child = parent*2;
		//
		// }
		// }
		//
		// if (array[parent*2] != null && array[parent*2+1] == null) {
		// child = parent*2;
		// while (array[parent].priority > array[child].priority) {
		// tempPair = array[parent];
		// array[parent] = array[child];
		// array[child] = tempPair;
		// parent--;
		// child = parent*2;
		// }
		// }

		// for (parent = size / 2; parent > 0; parent--) {
		// child = parent * 2;
		//
		// if (array[parent * 2 + 1] != null) {
		// if (array[child].priority > array[child + 1].priority) {
		// child--;
		// }
		//
		// if (array[parent].priority > array[child].priority) {
		// tempPair = array[parent];
		// array[parent] = array[child];
		// array[child] = tempPair;
		// }
		//
		// } else if (array[parent * 2 + 1] == null && array[parent * 2] == null) {
		//
		// if (array[parent].priority > array[child].priority) {
		// tempPair = array[parent];
		// array[parent] = array[child];
		// array[child] = tempPair;
		// }
		// } else if (array[parent * 2] == null) {
		// parent--;
		// }
		//
		// }
	}
}
